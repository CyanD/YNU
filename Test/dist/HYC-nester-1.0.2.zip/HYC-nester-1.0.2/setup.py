from distutils.core import setup

setup(
    name='HYC-nester',
    version="1.0.2",
    py_modules=["mytest"],
    author="HYC",
    author_email="yunchaohe@gmail.com",
    url="http://yunchao.wordpress.com",
    description="A simple printer of nested lists",
    )
